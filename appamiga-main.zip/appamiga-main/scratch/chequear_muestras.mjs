import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';

const samplesDir = path.join(process.cwd(), 'muestras');
const files = fs.readdirSync(samplesDir).filter(f => f.endsWith('.xlsx'));

files.forEach(fileName => {
    console.log(`\n--- ANALIZANDO: ${fileName} ---`);
    const filePath = path.join(samplesDir, fileName);
    const fileBuffer = fs.readFileSync(filePath);
    const workbook = XLSX.read(fileBuffer);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    
    // Obtener las cabeceras (primera fila con datos)
    const json = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    if (json.length > 0) {
        console.log("Cabeceras detectadas:", json[0]);
        
        // Ver una fila de ejemplo para ver los tipos de datos
        if (json.length > 1) {
            console.log("Fila de ejemplo:", json[1]);
        }
    } else {
        console.log("El archivo parece estar vacío.");
    }
});
