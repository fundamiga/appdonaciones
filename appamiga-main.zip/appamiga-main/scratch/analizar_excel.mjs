import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'muestras', 'COPIA MELI.xlsx');

try {
    const fileBuffer = fs.readFileSync(filePath);
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    
    const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, range: 0 });
    
    // Print rows 0-30 with ALL columns clearly labeled
    console.log('=== PRIMERAS 30 FILAS CON INDICES DE COLUMNA ===');
    for (let i = 0; i < Math.min(30, rows.length); i++) {
        const row = rows[i];
        if (!row || row.length === 0) {
            console.log(`Fila ${i}: [VACÍA]`);
            continue;
        }
        console.log(`\nFila ${i} (${row.length} cols):`);
        for (let j = 0; j < row.length; j++) {
            if (row[j] !== null && row[j] !== undefined) {
                console.log(`  Col[${j}] = ${JSON.stringify(row[j])}`);
            }
        }
    }
    
    // Find all FECHA rows
    console.log('\n\n=== TODAS LAS FECHAS ENCONTRADAS ===');
    rows.forEach((row, i) => {
        const col0 = String(row[0] || '').trim().toUpperCase();
        if (col0.includes('FECHA')) {
            console.log(`Fila ${i}: "${row[0]}"`);
        }
    });

    // Count all location headers
    console.log('\n\n=== TODAS LAS UBICACIONES (primeras 200 filas) ===');
    const locs = ['5 CON 6', '6 CON 6', 'CARTON', 'GUACANDA', 'GALERIA', 'GUABINAS', 'MAYORISTA', 'ROZO', 'BOLIVAR', '2 CON 10'];
    for (let i = 0; i < Math.min(200, rows.length); i++) {
        const col0 = String(rows[i]?.[0] || '').trim().toUpperCase();
        if (locs.includes(col0)) {
            console.log(`Fila ${i}: "${rows[i][0]}" - next cols: Col1=${rows[i][1]}, Col2=${rows[i][2]}`);
        }
    }

} catch (err) {
    console.error('Error:', err);
}
