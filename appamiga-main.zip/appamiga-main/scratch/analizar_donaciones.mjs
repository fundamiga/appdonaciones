import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';

// Analizar EXCEL DONACIONES.xlsx
const filePath = path.join(process.cwd(), 'muestras', 'EXCEL DONACIONES.xlsx');

try {
    const fileBuffer = fs.readFileSync(filePath);
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    
    console.log('Hojas encontradas:', workbook.SheetNames);
    
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    
    // Ver como filas crudas (header: 1 = array de arrays)
    const rawRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
    
    console.log(`\nTotal filas: ${rawRows.length}`);
    console.log('\n=== TODAS LAS FILAS (primeras 30) ===');
    for (let i = 0; i < Math.min(30, rawRows.length); i++) {
        const row = rawRows[i];
        if (!row || row.length === 0) {
            console.log(`Fila ${i}: [VACÍA]`);
            continue;
        }
        console.log(`\nFila ${i} (${row.length} cols):`);
        for (let j = 0; j < row.length; j++) {
            if (row[j] !== null && row[j] !== undefined && row[j] !== '') {
                console.log(`  Col[${j}] = ${JSON.stringify(row[j])} (tipo: ${typeof row[j]})`);
            }
        }
    }
    
    // Ahora ver con sheet_to_json normal (con cabeceras detectadas)
    console.log('\n\n=== COMO JSON (sheet_to_json default) ===');
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { raw: false, defval: '' });
    if (jsonData.length > 0) {
        console.log('Keys (columnas) del primer registro:', Object.keys(jsonData[0]));
        console.log('\nPrimeros 5 registros:');
        jsonData.slice(0, 5).forEach((row, i) => {
            console.log(`\nRegistro ${i}:`, JSON.stringify(row, null, 2));
        });
    } else {
        console.log('No se generaron registros con sheet_to_json default');
    }

} catch (err) {
    console.error('Error:', err);
}
