import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';

const NORMALIZAR_UBICACION = {
  '5 CON 6': '5ta con 6ta',
  '5TA CON 6TA': '5ta con 6ta',
  '6 CON 6': '6ta con 6ta',
  '6TA CON 6TA': '6ta con 6ta',
  '2 DA CON 10': '2da con 10',
  '2DA CON 10': '2da con 10',
  '2 CON 10': '2da con 10',
  'BOLIVAR': 'Bolivar',
  'CARTON COLOMBIA': 'Carton Colombia',
  'CARTON': 'Carton Colombia',
  'GUACANDA': 'Guacanda',
  'GALERIA': 'Galeria',
  'GUABINAS': 'Guabinas',
  'MAYORISTA': 'Mayorista',
  'ROZO': 'Rozo'
};

const samplesDir = path.join(process.cwd(), 'muestras');
const files = fs.readdirSync(samplesDir).filter(f => f.endsWith('.xlsx'));

files.forEach(fileName => {
  const filePath = path.join(samplesDir, fileName);
  const fileBuffer = fs.readFileSync(filePath);
  const workbook = XLSX.read(fileBuffer);
  const worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });

  let esPlantilla = false;
  let detectIndex = -1;
  for (let i = 0; i < Math.min(50, rows.length); i++) {
    const col0 = String(rows[i]?.[0] || '').trim().toUpperCase();
    if (col0.startsWith('FECHA:')) {
      esPlantilla = true;
      detectIndex = i;
      break;
    }
  }

  console.log(`\nArchivo: ${fileName} - Filas: ${rows.length}`);
  console.log(`Es Plantilla? ${esPlantilla} (Detectado en fila ${detectIndex})`);

  if (!esPlantilla) {
    // try standard fallback logic to see if it yields results
    const jsonDataRaw = XLSX.utils.sheet_to_json(worksheet, { raw: false, defval: '' });
    const cols = jsonDataRaw.length > 0 ? Object.keys(jsonDataRaw[0]) : [];
    console.log(`Columnas Estandar Detectadas:`, cols.slice(0, 5));
    // Let's filter like we do
    const valid = jsonDataRaw.filter(f => {
        return (parseFloat(f.VALOR) > 0 || parseFloat(f.RECAUDO) > 0 || parseFloat(f.TOTAL) > 0 || parseFloat(f.MONTO) > 0 || parseFloat(f.VALORTOTAL) > 0)
    });
    console.log(`Registros Estandar que parecen tener valor: ${valid.length}`);
  } else {
    // test plantilla logic
    let numRegs = 0;
    let ubicacionActual = '';
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!row || row.length === 0) continue;
      const col0 = String(row[0] || '').trim().toUpperCase();
      if (col0 === 'TOTAL TURNO' || col0 === 'PARQUEADEROS') { if (col0 === 'TOTAL TURNO') ubicacionActual = ''; continue; }
      if (NORMALIZAR_UBICACION[col0]) {
        ubicacionActual = col0;
        continue;
      }
      if (ubicacionActual && col0 !== '' && !col0.startsWith('FECHA:')) {
        let mTotal = 0;
        for (let c = 1; c < row.length; c++) {
          const rawVal = row[c] === null || row[c] === undefined ? '0' : String(row[c]);
          const limpio = rawVal.replace(/[^\d.]/g, '');
          const v = parseFloat(limpio);
          if (!isNaN(v) && v > mTotal) mTotal = v;
        }
        if (mTotal > 0) numRegs++;
      }
    }
    console.log(`Registros Plantilla Extraidos: ${numRegs}`);
  }
});
