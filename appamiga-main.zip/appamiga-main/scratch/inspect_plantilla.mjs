import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';

const samplesDir = path.join(process.cwd(), 'muestras');
const filePath = path.join(samplesDir, 'plantilla.xlsx');

try {
  const fileBuffer = fs.readFileSync(filePath);
  const workbook = XLSX.read(fileBuffer);
  const worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });

  let esPlantillaMeli = false;
  let esPlantillaLimpia = false;
  for (let i = 0; i < Math.min(10, rows.length); i++) {
    const col0 = String(rows[i]?.[0] || '').trim().toUpperCase();
    if (col0.startsWith('FECHA:')) {
      esPlantillaMeli = true;
      break;
    }
    const col1 = String(rows[i]?.[1] || '').trim().toUpperCase();
    if (col1 === 'VALOR TOTAL DE DONACIONES') {
      esPlantillaLimpia = true;
      break;
    }
  }

  let registros = [];
  if (esPlantillaLimpia) {
    let fechaActual = new Date().toISOString().split('T')[0];
    let ubicacionActual = '';

    // Intentar leer la fecha en la celda 0,0 si es numero
    if (rows.length > 0 && typeof rows[0]?.[0] === 'number') {
      const dateVal = XLSX.SSF.parse_date_code(rows[0][0]);
      if (dateVal) {
        fechaActual = `${dateVal.y}-${String(dateVal.m).padStart(2, '0')}-${String(dateVal.d).padStart(2, '0')}`;
      }
    }

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!row || row.length === 0) continue;

      const col0 = String(row[0] || '').trim();
      const col0Upper = col0.toUpperCase();
      const col1 = String(row[1] || '').trim().toUpperCase();

      if (col1 === 'VALOR TOTAL DE DONACIONES') {
        // Encontramos una cabecera de ubicacion
        // Mapear la ubicacion!  "5 CON 6" -> "5ta con 6ta"
        // Pero OJO, puede que falte NORMALIZAR_UBICACION (revisar que NORMALIZAR_UBICACION tenga '5 CON 6')
        ubicacionActual = col0Upper; // o podemos usar corregirUbicacion() despues
        continue;
      }

      if (ubicacionActual && col0 !== '' && typeof row[1] === 'number') {
        const valor = row[1];
        const cantidad = typeof row[2] === 'number' ? row[2] : 0;
        registros.push({
           fecha: fechaActual,
           ubicacion: ubicacionActual,
           trabajador: col0,
           valor: valor,
           cantidad: cantidad
        });
      }
    }
  }

  console.log(`Es Limpia: ${esPlantillaLimpia}`);
  console.log(`Extraidos: ${registros.length}`);
  if (registros.length > 0) {
     console.log('Sample:', registros.slice(0, 3));
  }
} catch (e) {
  console.log("Error:", e);
}
