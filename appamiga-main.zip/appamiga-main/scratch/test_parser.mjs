import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';

const NORMALIZAR_UBICACION = {
  '5 CON 6': '5ta con 6ta',
  '5TA CON 6TA': '5ta con 6ta',
  '6 CON 6': '6ta con 6ta',
  '6TA CON 6TA': '6ta con 6ta',
  '2 DA CON 10': '2da con 10',
  '2DA CON 10': '2da con 10',
  '2 CON 10': '2da con 10',
  'BOLIVAR': 'Bolivar',
  'CARTON COLOMBIA': 'Carton Colombia',
  'CARTON': 'Carton Colombia', // Added CARTON
  'GUACANDA': 'Guacanda',
  'GALERIA': 'Galeria',
  'GUABINAS': 'Guabinas',
  'MAYORISTA': 'Mayorista',
  'ROZO': 'Rozo'
};

const corregirUbicacion = (name) => {
  const upper = name.trim().toUpperCase();
  return NORMALIZAR_UBICACION[upper] || name;
};

const MESES = {
  'ENERO': '01', 'FEBRERO': '02', 'MARZO': '03', 'ABRIL': '04', 'MAYO': '05', 'JUNIO': '06',
  'JULIO': '07', 'AGOSTO': '08', 'SEPTIEMBRE': '09', 'OCTUBRE': '10', 'NOVIEMBRE': '11', 'DICIEMBRE': '12'
};

const formatearFechaEspecial = (texto) => {
  const clean = texto.toUpperCase().replace('FECHA:', '').trim();
  const partes = clean.split(' ').filter(Boolean); // filter out empty strings like "01 NOV  2025" -> ["01", "NOV", "2025"]
  if (partes.length >= 3) {
    const dia = partes[0].padStart(2, '0');
    const mes = MESES[partes[1]] || '01';
    const anio = partes[2];
    return `${anio}-${mes}-${dia}`;
  }
  return new Date().toISOString().split('T')[0];
};

const filePath = path.join(process.cwd(), 'muestras', 'COPIA MELI.xlsx');
const fileBuffer = fs.readFileSync(filePath);
const workbook = XLSX.read(fileBuffer);
const firstSheetName = workbook.SheetNames[0];
const worksheet = workbook.Sheets[firstSheetName];
        
const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

let esPlantilla = false;
for(let i=0; i<Math.min(10, rows.length); i++){
    const col0 = String(rows[i]?.[0] || '').trim().toUpperCase();
    if (col0.startsWith('FECHA:')) {
        esPlantilla = true;
        break;
    }
}

if (!esPlantilla) {
    console.log("No es plantilla");
    process.exit(0);
}

const registros = [];
let fechaActual = new Date().toISOString().split('T')[0];
let ubicacionActual = '';

for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.length === 0) continue;

    const col0 = String(row[0] || '').trim();
    const col0Upper = col0.toUpperCase();

    if (col0Upper.startsWith('FECHA:')) {
        fechaActual = formatearFechaEspecial(col0Upper);
        continue;
    }

    if (col0Upper === 'PARQUEADEROS' || col0Upper === 'TOTAL TURNO' || col0Upper === '') {
        if (col0Upper === 'TOTAL TURNO') {
            ubicacionActual = '';
        }
        continue;
    }

    // Is it a location? We can check if it's in the keys, or if it matches mapped keys.
    // Notice that we added "CARTON" since it's in the data.
    if (NORMALIZAR_UBICACION[col0Upper]) {
        ubicacionActual = corregirUbicacion(col0Upper);
        continue;
    }

    if (ubicacionActual && col0Upper !== '') {
        // Find total. 
        // In the data: Col[10] is sum of coins, Col[17] is sum of bills, Col[18] is total.
        // What if length varies? Let's get the max numeric value from the last 3 columns.
        let mTotal = 0;
        for (let c = row.length - 1; c >= Math.max(1, row.length - 5); c--) {
            const v = parseFloat(String(row[c] || '0').replace(/[^\d.]/g, ''));
            if (!isNaN(v) && v > mTotal) mTotal = v;
        }

        if (mTotal > 0) {
            registros.push({
                fecha: fechaActual,
                ubicacion: ubicacionActual,
                trabajador: col0Upper,
                valor: mTotal
            });
        }
    }
}

console.log("Registros extraídos:", registros.length);
console.log(registros.slice(0, 10));
